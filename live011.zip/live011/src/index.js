import parser from "lambda-multipart-parser";
import { response } from "./utils/response.js";

export async function handler(event) {
  const { files } = await parser.parse(event);
  const [file] = files;

  if (!file) {
    return response(400, {
      error: "File is required.",
    });
  }

  return response(200, body);
}
